# Dory Import Wizard CSV 测试包

## valid

- customers-basic.csv：常规类型、空值、Unicode。
- customers-edge-values.csv：逗号、双引号、单元格换行、NULL、空字符串和空格。
- leading-zeros.csv：邮编、电话、SKU、账号；应保持 String。
- mixed-types.csv：混合整数、浮点、布尔和日期；无法全量转换的列应保持 String。
- numeric-boundaries.csv：Int64 上下界、前导零标识符和科学计数法。

## settings

- no-header.csv：关闭“First row is a header”。
- semicolon-delimiter.csv：手动选择分号 delimiter。
- pipe-delimiter.csv：手动选择竖线 delimiter。
- tab-delimiter.tsv：Tab delimiter。

## encoding

- utf8-bom.csv：UTF-8 BOM。
- utf16le-bom.csv：UTF-16LE BOM。
- utf16be-bom.csv：UTF-16BE BOM。

## errors

- duplicate-headers.csv：重复列名，应要求修正或明确报错。
- ragged-rows.csv：列数不一致，应分析失败且不产生部分导入。
- empty.csv：空文件，应分析失败。

## stress

- customers-10000.csv：10,000 行，包含周期性 NULL 与 Unicode，用于批次、进度和取消测试。
